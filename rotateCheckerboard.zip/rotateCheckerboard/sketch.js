var rot= 0
function setup() {
  createCanvas(400,400);
}

function draw() {
 // background(220);
  rot=rot+(1/20);
  //checkerboard (width,8,'blue','white');
  rotateCheckerboard(width/2.5,8,200,200,color(0,255,0),color(0), rot);
  rotateCheckerboard(width/8,8,100,100,color(255),color(200,100,40), rot*-1);
  rotateCheckerboard(width/8,8,300,100,color(0,100,200),color(250,150,150), rot*-1);
  rotateCheckerboard(width/12,8,350,75,color(250,250,0),color(100,0,200), rot);
}
function checkerboard(sz,sqCount,color1,color2) {
  noStroke();
  rectMode(LEFT);  
  var spacing = sz/sqCount;
  
  //controls the number of rows
  for (var y=0; y<sqCount; y=y+1) {
    //controls columns
    for (var x=0; x<sqCount; x=x+1) {
      if ((x+y)%2 == 0) {
        fill(color1);
      } else {
        fill(color2);
      }
      rect(x*spacing,y*spacing,spacing,spacing);
    }
  }
}
function rotateCheckerboard (sz,sqCount,x,y,color1,color2,r) {
	push();
	rectMode(CORNER);
	translate(x,y);
	rotate(r);
	translate(-sz/2, -sz/2);
	checkerboard(sz,sqCount,color1,color2);
	pop();
}


