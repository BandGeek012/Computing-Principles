var bg;
var bx1,by1,bw,bh
var bx2,by2
var bx3,by3
var bx4,by4
var bx5,by5
var bx6,by6
function setup() {
  createCanvas(600,400);
  bg=background
  bw=100; bh=100;
  //button 1 (white)
  bx1=100; by1=100;
  //button 2 (black)
  bx2=200; by2=200;
  //button 3 (green)
  bx3=300; by3=100;
  //button 4 (blue)
  bx4=400; by4=200;
  //button 5 (red)
  bx5=300; by5=300;
  //button 6 (yellow)
  bx6=100; by6=300;
}

function draw() {
  noStroke();
  //button white
  fill(255);rect(bx1,by1,bw,bh);
   //button black
  fill(0);rect(bx2,by2,bw,bh);
  //button green
  fill(0,255,0);rect(bx3,by3,bw,bh);
  //button blue
  fill(0,0,255); rect(bx4,by4,bw,bh);
  //button red
  fill(255,0,0); rect(bx5,by5,bw,bh);
  //button yellow
  fill(255,255,0);
  rect(bx6,by6,bw,bh);
}
function mousePressed() {
  //white
    if(mouseX>bx1 && mouseX<bx1+bw && mouseY>by1 && mouseY<by1+bh){ bg(255);}
  //black
  if (mouseX>bx2 && mouseX<bx2+bw && mouseY>by2 && mouseY<by2+bh){bg(0);} 
    //green
    if(mouseX>bx3 && mouseX<bx3+bw && mouseY>by3 && mouseY<by3+bh){ bg(0,255,0);}
    //blue
    if(mouseX>bx4 && mouseX<bx4+bw && mouseY>by4 && mouseY<by4+bh){bg(0,0,255);}
    //red
    if(mouseX>bx5 && mouseX<bx5+bw && mouseY>by5 && mouseY<by5+bh){bg(255,0,0);}
    //yellow
    if(mouseX>bx6 && mouseX<bx6+bw && mouseY>by5 && mouseY<by6+bh){bg(255,255,0);}
}