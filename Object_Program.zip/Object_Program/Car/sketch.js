function setup() {
  createCanvas(600, 400);
  road = new Road(249, 0, 150, 399, "black")
  car = new Car(270, 299, 50, 74, "blue", LEFT_ARROW, RIGHT_ARROW)
}

function draw() {
  background(20, 200, 80);
  noStroke();
  fill(0);
  road.display();
  road.moveX();
  stroke('orange');
  car.display();
  car.moveX();
  
  //method of ending the game
  if (car.x<road.x||car.x+car.w>road.x+road.w){
    car.clr = color('red');
    road.clr = color('red');
    background('red');
    car.speed = 0;
    road.speed = 0;
  }
}

function Road(posx, posy, w, h, clr) {
  //Properties of road

  this.x = posx;
  this.y = posy;
  this.w = w;
  this.h = h;
  this.clr = clr;
  this.speed = 1;
  //method of road moving
  this.moveX = function() {
    this.x = this.x + this.speed;
    if (this.x > width - this.w || this.x < 0) {
      this.speed = -this.speed
    }
    this.speed = this.speed*1.001
  }
  this.display = function() {
    push();
    //rectMode(CENTER);
    fill(this.clr)
    rect(this.x, this.y, this.w, this.h);
    fill(0);
    pop();
  }
}

function Car(posx, posy, w, h, clr, btn1, btn2) {
  //properties of car
  this.left = btn1
  this.right = btn2
  this.x = posx;
  this.y = posy;
  this.w = w;
  this.h = h;
  this.clr = clr;
  this.speed = 1.5;
  //method of car moving
  this.moveX = function() {
    this.speed = this.speed*1.001
    
    if (keyIsDown(btn1)) {
     this.x = this.x - this.speed;
    }else if (keyIsDown(btn2)) {
    this.x = this.x + this.speed;
    } 
  }
  this.display = function() {
    push();
    //rectMode(CENTER);
    fill(this.clr)
    rect(this.x, this.y, this.w, this.h);
    fill(0);
    pop();
  }
}