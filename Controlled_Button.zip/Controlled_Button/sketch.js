var rot= 0;
var speed=0
var g1
var g2
function setup() {
  createCanvas(400,400);
  g1=color(0);
  g2=color(255);
}

function draw() {
 //background(220);
  //checkerboard (width,8,'blue','white');
  rot=rot+speed
  rotateCheckerboard(width/2.5,8,200,200,g1,g2, rot);
rotateCheckerboard(width/8,8,100,100,g2,g1, rot*-1);
rotateCheckerboard(width/8,8,300,100,g2,g1, rot*-1);
 rotateCheckerboard(width/12,8,350,75,g1,g2, rot);
  rect(0,0,50,50);
  rect(50,0,60,50);
  rect(110,0,50,50);
  rect(160,0,50,50);
  rect(0,50,50,50);
  text("forward",5,25);
  text("backwards",50,25);
  text("inverse",115,25);
  text("normal",165,25);
  text("Stop",10,75);
}
function checkerboard(sz,sqCount,color1,color2) {
  noStroke();
  rectMode(LEFT);  
  var spacing = sz/sqCount;
 
  //controls the number of rows
  for (var y=0; y<sqCount; y=y+1) {
    //controls columns
    for (var x=0; x<sqCount; x=x+1) {
      if ((x+y)%2 == 0) {
        fill(color1);
      } else {
        fill(color2);
      }
      rect(x*spacing,y*spacing,spacing,spacing);
    }
  }
}
function mousePressed () {
  if (mouseX>0 && mouseX<50 && mouseY>0 && mouseY<50){
   speed=1/20
  }
  if (mouseX>0 && mouseX<50 && mouseY>50 && mouseY<100){
   speed=0
  }
  if (mouseX>50 && mouseX<100 && mouseY>0 && mouseY<60){
   speed=-1/20
  }
  if (mouseX>110 && mouseX<160 && mouseY>0 && mouseY<50){
   g1=color("white"); g2=color("black");
  }
  if (mouseX>160 && mouseX<210 && mouseY>0 && mouseY<50){
   g1=color(0); g2=color(255);
  }
}
function rotateCheckerboard (sz,sqCount,x,y,color1,color2,r) {
	push();
	rectMode(CORNER);
	translate(x,y);
	rotate(r);
	translate(-sz/2, -sz/2);
	checkerboard(sz,sqCount,color1,color2);
	pop();
}


