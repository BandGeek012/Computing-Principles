function Clouds(x,y,size) {
  this.x=x;
  this.y=y;
  this.r= (75);
  this.col=color(150);

this.display = function() {
  fill(this.col);
  ellipse(this.x,this.y,this.r);
}
this.update = function() {
  this.x += random(-1,1);
}
}