var rain = [];
var clouds = [];
function setup() {
  createCanvas(400,400);
  for (var i=0; i<10; i++) {
    clouds[i]= new Clouds(random(0,width),25,50);
  }
 rain=new Rain(random(0,width),random(0,height),rain.r)
}

function draw() {
  background(200);
  fill(100,150,100);
  rect(0,329,width,70)
  for (var i=0; i<25; i++){
  clouds[i].update();
  clouds[i].display();
  }
  rain.display();
}