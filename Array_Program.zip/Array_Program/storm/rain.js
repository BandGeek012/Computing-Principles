function Rain(x,y) {
  this.x=x;
  this.y=y;
  this.size= (this.w,this.h);
  this.col=color(200,200,255,50);

this.display = function() {
  rect(this.x,this.y,this.w,this.h);
}
}