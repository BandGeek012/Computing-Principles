function setup() {
  createCanvas(400, 350);
	background("lightblue");
	noStroke()
	fill("orange");
	ellipse(350,30,50,50);
		fill("beige");
	rect(0,250,399,100);
	fill("tan");
	rect(0,200,399,50);
	fill("green");
	rect(175,75,25,90);
	rect(300,75,25,90);
	rect(175,140,150,30);
	rect(225,50,55,210);
	fill("tan");

}

function draw() {
  
}